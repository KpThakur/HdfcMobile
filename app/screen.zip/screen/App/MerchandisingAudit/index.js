import React from 'react'
import { View, Text } from 'react-native'
import MerchandisingAudit from './component/MerchandisingAudit'

export default function index() {
    return (
        <MerchandisingAudit/>
    )
}

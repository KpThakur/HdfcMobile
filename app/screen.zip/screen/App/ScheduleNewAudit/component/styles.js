import { StyleSheet } from "react-native"
export const styles = StyleSheet.create({
    contianer:{
        flex:1,
        padding:20,
        justifyContent:"space-evenly"
    },
    txt_head:{
        color:"#000",
        fontSize:18,
        fontWeight:"600"
    },
    date_time:{
        flexDirection:'row',
        paddingVertical:10,
        alignItems:"center",
        paddingRight:50,
        paddingLeft:10,
        backgroundColor:"#eee"
    }
})

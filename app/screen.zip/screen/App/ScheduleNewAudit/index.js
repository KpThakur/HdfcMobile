import React from 'react'
import { View, Text } from 'react-native'
import ScheduleNewAudit from './component/ScheduleNewAudit'

export default function index() {
    return (
        <ScheduleNewAudit/>
    )
}

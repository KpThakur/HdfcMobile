import React, { useState } from 'react';
import { View, Text, Image, TextInput, ScrollView, TouchableOpacity } from 'react-native';
import { styles } from './styles'
import Button from '../.../../../../../component/Button'
const LoginScreen = () => {
    const [isSecure, setisSecure] = useState(true)
    const [isChecked, setisChecked] = useState(false)
    const handlePassword = () => {
        setisSecure(!isSecure)
    }
    const handleCheck=()=>{
        setisChecked(!isChecked)
    }
    return (
        <ScrollView style={{ flex: 1, width: "100%" }}>
            <View style={styles.container}>
                <Image source={require('../../../../assets/images/HDFC_Bank_Logo.svg.png')} style={{ width: "50%", resizeMode: "contain", marginTop: 10 }} />
                <Image source={require('../../../../assets/images/Audit.png')} style={styles.img} />
                <Text style={styles.header}>Login</Text>
                <View style={{ width: '100%' }}>
                    <View>
                        <TextInput placeholder="Email  Address / Employee ID" style={styles.text_field} />
                    </View>
                    <View>
                        <TextInput placeholder="Password" secureTextEntry={isSecure} style={styles.text_field} />
                        <TouchableOpacity onPress={() => handlePassword()}
                            style={{ zIndex:999,width: 30, height: 30, resizeMode: 'contain', position: "absolute", right: 20, top: 30 }} >
                            {isSecure ?
                                <Image source={require('../../../../assets/images/Group_7.png')}/>
                                : <Image source={require('../../../../assets/images/eye.png')}/>
                            }
                        </TouchableOpacity>
                    </View>
                    <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 10 }}>
                        <View style={{flexDirection:"row"}}>
                        <TouchableOpacity onPress={()=>handleCheck()} style={{marginRight:5}}>
                            {
                                isChecked?
                                <Image source={require('../../../../assets/images/check-button.png')} style={{width:15,height:15}}/>:
                                <Image source={require('../../../../assets/images/unchecked.png')} style={{width:20,height:20}}/>
                            }
                            
                        </TouchableOpacity>
                        <Text style={{ color: "#000", fontSize: 12 }}>Keep Me Sign in</Text>
                        </View>
                        
                        <TouchableOpacity><Text style={styles.txt}>Forget Password ?</Text></TouchableOpacity>
                    </View>
                    <Button title="Log in"/>
                </View>
            </View>
        </ScrollView>
    )
}
export default LoginScreen;
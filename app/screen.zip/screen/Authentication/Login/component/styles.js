import { StyleSheet,Dimensions } from "react-native"
import { DARK_BLUE_COLOR,PRIMARY_BLUE_COLOR } from "../../../../utils/constant"

const WindowWidth=Dimensions.get('window').width
const WindowHeight=Dimensions.get('window').height
const ratio=WindowWidth
export const styles = StyleSheet.create({
    container:{
        flex:1,
        alignItems:'center',
        paddingHorizontal:30,
        backgroundColor:"white",
    },
    header:{
        fontSize:28,
        fontWeight:"700",
        color:DARK_BLUE_COLOR
    },
    text_field:{
        backgroundColor:"#eee",
        borderRadius:20,
        width:"100%",
        marginVertical:10,
        paddingLeft:20,
        color:"gray"
    },
    txt:{
        color:PRIMARY_BLUE_COLOR,
        fontSize:12
    },
    img:{
        width:WindowWidth,
        height:WindowHeight/3,
        resizeMode:"contain",
    }
})

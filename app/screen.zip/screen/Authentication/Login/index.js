import React from 'react';
import LoginScreen from './component/login';

const Login = ()=>{
    return(<LoginScreen/>)
}
export default Login;